﻿using System;
using System.Collections.Generic;
using System.Linq;
using BudgetBuddy.Models;
using BudgetBuddy.Services;

namespace BudgetBuddy.Reports
{
    public static class GraphHelperXY
    {
        public static void DisplayBalanceOverTime(DatabaseService db, int year, int month)
        {
            Console.Clear();
            var transactions = db.GetTransactionsForMonth(year, month)
                .OrderBy(t => t.Date)
                .ToList();
            if (transactions.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("No transactions found for this month.");
                Console.ResetColor();
                Console.ReadKey();
                return;
            }
            int daysInMonth = DateTime.DaysInMonth(year, month);
            decimal[] balance = new decimal[daysInMonth];
            decimal current = 0;

            for (int day = 1; day <= daysInMonth; day++)
            {
                current += transactions
                    .Where(t => t.Date.Day == day)
                    .Sum(t => t.Type.Equals("Income", StringComparison.OrdinalIgnoreCase) ? t.Amount : -t.Amount);

                balance[day - 1] = current;
            }
            decimal min = balance.Min();
            decimal max = balance.Max();
            decimal range = max - min;
            if (range == 0) range = 1;
            int height = 15;
            int width = daysInMonth;
            char[,] grid = new char[height, width];
            for (int y = 0; y < height; y++)
                for (int x = 0; x < width; x++)
                    grid[y, x] = ' ';
            for (int i = 0; i < width; i++)
            {
                int level = (int)Math.Round((balance[i] - min) / range * (height - 1));
                int y = height - 1 - level;
                grid[y, i] = 'o';
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"=== Daily Balance Chart — {year}-{month:00} ===");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"(Max £{max:F2}  Min £{min:F2})");
            Console.ResetColor();
            Console.WriteLine();

            for (int y = 0; y < height; y++)
            {
                Console.Write("| ");
                for (int x = 0; x < width; x++)
                    Console.Write(grid[y, x]);
                Console.WriteLine();
            }

            Console.WriteLine("└" + new string('─', width + 1));
            Console.WriteLine("   Days ->");

            Console.WriteLine("\nPress any key...");
            Console.ReadKey();
        }
    }
}