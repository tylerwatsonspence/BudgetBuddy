﻿using System;
using System.Collections.Generic;
using BudgetBuddy.Services;

namespace BudgetBuddy.Reports
{
    public static class ReportGenerator
    {
        public static void Monthly(DatabaseService db, int year, int month)
        {
            Console.Clear();
            var (inc, exp) = db.GetTotalsForMonth(year, month);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"=== Monthly Report — {year}-{month:00} ===");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Total Income : £{inc:F2}");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Total Expense: £{exp:F2}");
            Console.ResetColor();
            decimal net = inc - exp;
            Console.ForegroundColor = net >= 0 ? ConsoleColor.Green : ConsoleColor.Red;
            Console.WriteLine($"Net Balance  : £{net:F2}\n");
            Console.ResetColor();
            var byCat = db.GetCategorySpendForMonth(year, month);
            if (byCat.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("No expenses for this month.");
                Console.ResetColor();
                Console.WriteLine("\nPress any key...");
                Console.ReadKey();
                return;
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Category Breakdown (Expenses):");
            Console.ResetColor();
            decimal max = 0;
            foreach (var v in byCat.Values)
            { if (v > max) max = v; }
            foreach (var kv in byCat)
            {
                int bar = max == 0 ? 0 : (int)(kv.Value / max * 30);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write($"{kv.Key,-14}");
                Console.ResetColor();
                Console.Write(" | ");
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.Write(new string('█', bar));
                Console.ResetColor();
                Console.WriteLine($" £{kv.Value:F2}");
            }
            Console.WriteLine("\nPress any key...");
            Console.ReadKey();
        }
        public static void Yearly(DatabaseService db, int year)
        {
            Console.Clear();
            var (inc, exp) = db.GetTotalsForYear(year);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"=== Yearly Report — {year} ===");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Total Income : £{inc:F2}");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Total Expense: £{exp:F2}");
            Console.ResetColor();
            decimal net = inc - exp;
            Console.ForegroundColor = net >= 0 ? ConsoleColor.Green : ConsoleColor.Red;
            Console.WriteLine($"Net Balance  : £{net:F2}\n");
            Console.ResetColor();
            var byCat = db.GetCategorySpendForYear(year);
            if (byCat.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("No expenses recorded this year.");
                Console.ResetColor();
                Console.WriteLine("\nPress any key...");
                Console.ReadKey();
                return;
            }
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Top Categories (Expenses):");
            Console.ResetColor();
            decimal max = 0;
            foreach (var v in byCat.Values)
            { if (v > max) max = v; }
            foreach (var kv in byCat)
            {
                int bar = max == 0 ? 0 : (int)(kv.Value / max * 30);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write($"{kv.Key,-14}");
                Console.ResetColor();
                Console.Write(" | ");
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.Write(new string('█', bar));
                Console.ResetColor();
                Console.WriteLine($" £{kv.Value:F2}");
            }
            Console.WriteLine("\nPress any key...");
            Console.ReadKey();
        }
    }
}