﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using BudgetBuddy.Models;
using BudgetBuddy.Services;

namespace BudgetBuddy.Reports
{
    public static class CsvExporter
    {
        public static void ExportAll(List<Transaction> transactions, string filePath)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(filePath)!);
            using var sw = new StreamWriter(filePath);
            sw.WriteLine("Id,Date,Type,Category,Amount,Description");
            foreach (var t in transactions)
            {
                sw.WriteLine($"{t.Id},{t.Date:yyyy-MM-dd},{t.Type},{Escape(t.Category)},{t.Amount.ToString(CultureInfo.InvariantCulture)},{Escape(t.Description)}");
            }
        }
        public static void ExportMonth(DatabaseService db, int year, int month, string filePath)
        {
            var tx = db.GetTransactionsForMonth(year, month);
            ExportAll(tx, filePath);
        }
        private static string Escape(string? s)
        {
            s ??= "";
            if (s.Contains(",") || s.Contains("\""))
                return "\"" + s.Replace("\"", "\"\"") + "\"";
            return s;
        }
    }
}

