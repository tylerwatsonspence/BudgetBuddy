﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using BudgetBuddy.Models;
using BudgetBuddy.Reports;

namespace BudgetBuddy.Services
{
    public class BudgetManager
    {
        private readonly DatabaseService dbService;
        private readonly List<Transaction> transactions;
        private readonly List<string> expenseCategories = new() { "Food", "Transport", "Bills", "Entertainment", "Shopping", "Other" };
        private readonly List<string> incomeCategories = new() { "Salary", "Gift", "Investment", "Freelance", "Other" };
        public BudgetManager()
        {
            dbService = new DatabaseService();
            transactions = dbService.GetAllTransactions();
        }
        public List<Transaction> GetTransactions() => transactions;
        public void ManageRecurrences()
        {
            Console.Clear();
            Console.WriteLine("=== Recurring Transactions ===");
            var recs = dbService.GetRecurrences();
            if (recs.Count == 0) Console.WriteLine("(none yet)");
            else
            {
                for (int i = 0; i < recs.Count; i++) { 
                    Console.WriteLine($"{i + 1}. {recs[i]}");
            } }
            Console.WriteLine("\n1) Add/Update  2) Delete  0) Back");
            Console.Write("Choose: ");
            var c = Console.ReadLine();
            if (c == "1")
            {
                Console.Write("Name: "); var name = Console.ReadLine() ?? "";
                Console.Write("Type (Income/Expense): "); var type = Console.ReadLine() ?? "Expense";
                Console.Write("Category: "); var cat = Console.ReadLine() ?? "Other";
                Console.Write("Amount: £"); if (!decimal.TryParse(Console.ReadLine(), out var amt)) { Console.WriteLine("Invalid."); Console.ReadKey(); return; }
                Console.Write("Day of Month (1-31): "); if (!int.TryParse(Console.ReadLine(), out var dom)) { Console.WriteLine("Invalid."); Console.ReadKey(); return; }
                Console.Write("Description: "); var desc = Console.ReadLine() ?? "";

                var r = new Recurrence(name, type, cat, amt, dom, desc);
                dbService.UpsertRecurrence(r);
                Console.WriteLine("\nSaved. Press any key...");
                Console.ReadKey();
            }
            else if (c == "2")
            {
                Console.Write("Enter index to delete: ");
                if (int.TryParse(Console.ReadLine(), out int idx) && idx >= 1 && idx <= recs.Count)
                {
                    dbService.DeleteRecurrence(recs[idx - 1].Id);
                    Console.WriteLine("Deleted.");
                }
                else Console.WriteLine("Invalid.");
                Console.ReadKey();
            }
        }
        public void ShowBalanceGraph()
        {
            Console.Clear();
            Console.Write("Enter month (1–12): ");
            if (!int.TryParse(Console.ReadLine(), out int m) || m < 1 || m > 12)
            {
                Console.WriteLine("Invalid month."); Console.ReadKey(); return;
            }
            Console.Write("Enter year: ");
            if (!int.TryParse(Console.ReadLine(), out int y) || y < 1900 || y > 3000)
            {
                Console.WriteLine("Invalid year."); Console.ReadKey(); return;
            }
            GraphHelperXY.DisplayBalanceOverTime(dbService, y, m);
        }
        public void ApplyRecurrences()
        {
            Console.Clear();
            Console.Write("Apply for month (1-12): ");
            if (!int.TryParse(Console.ReadLine(), out int m) || m < 1 || m > 12) { Console.WriteLine("Invalid."); Console.ReadKey(); return; }
            Console.Write("Year: ");
            if (!int.TryParse(Console.ReadLine(), out int y) || y < 1900 || y > 3000) { Console.WriteLine("Invalid."); Console.ReadKey(); return; }
            int added = dbService.ApplyRecurrencesForMonth(y, m);
            transactions.Clear();
            transactions.AddRange(dbService.GetAllTransactions());
            Console.WriteLine($"\nApplied {added} recurrence(s) into {y}-{m:00}.");
            Console.WriteLine("Press any key...");
            Console.ReadKey();
        }
        private string currencySymbolCache;
        public string CurrencySymbol
        {
            get
            {
                if (currencySymbolCache == null)
                    currencySymbolCache = dbService.GetSetting("CurrencySymbol") ?? "£";
                return currencySymbolCache;
            }
        }
        public void SettingsMenu()
        {
            Console.Clear();
            var current = dbService.GetSetting("CurrencySymbol") ?? "£";
            Console.WriteLine("=== Settings ===");
            Console.WriteLine($"1) Currency Symbol (current: {current})");
            Console.WriteLine("0) Back");
            Console.Write("\nChoose: ");
            var c = Console.ReadLine();
            if (c == "1")
            {
                Console.Write("Enter new symbol (e.g., £, $, €): ");
                var s = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(s))
                {
                    dbService.SetSetting("CurrencySymbol", s);
                    currencySymbolCache = s;
                    Console.WriteLine("Saved.");
                }
                else Console.WriteLine("Not changed.");
                Console.ReadKey();
            }
        }
        public void AddTransaction()
        {
            Console.Clear();
            Console.WriteLine("=== Add Transaction ===");
            Console.Write("Enter date (yyyy-mm-dd): ");
            if (!DateTime.TryParse(Console.ReadLine(), out DateTime date))
            {
                Console.WriteLine("Invalid date format. Press any key...");
                Console.ReadKey();
                return;
            }
            Console.Write("Type (Income/Expense): ");
            string type = Console.ReadLine()?.Trim();
            if (string.IsNullOrWhiteSpace(type) ||
                !(type.Equals("Income", StringComparison.OrdinalIgnoreCase) ||
                  type.Equals("Expense", StringComparison.OrdinalIgnoreCase)))
            {
                Console.WriteLine("Invalid type. Please enter 'Income' or 'Expense'.");
                Console.ReadKey();
                return;
            }
            string category = SelectCategory(type);
            Console.Write("Amount: £");
            if (!decimal.TryParse(Console.ReadLine(), out decimal amount) || amount <= 0)
            {
                Console.WriteLine("Invalid amount. Must be a positive number.");
                Console.ReadKey();
                return;
            }
            Console.Write("Description: ");
            string desc = Console.ReadLine();
            var t = new Transaction(date, type, category, amount, desc);
            transactions.Add(t);
            dbService.AddTransaction(t);

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\nTransaction added successfully!");
            Console.ResetColor();
            Console.ReadKey();
        }
        public void ListTransactions()
        {
            Console.Clear();
            Console.WriteLine("Date       | Type     | Amount    | Category     | Description");
            Console.WriteLine("---------------------------------------------------------------");
            if (transactions.Count == 0)
            {
                Console.WriteLine("No transactions found.");
            }
            else
            {
                foreach (var t in transactions)
                    Console.WriteLine(t);
            }
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();
        }
        public void ShowSummaryWithGraph()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("=== Summary ===");
            Console.ResetColor();
            decimal totalIncome = transactions.Where(t => t.Type.Equals("Income", StringComparison.OrdinalIgnoreCase)).Sum(t => t.Amount);
            decimal totalExpense = transactions.Where(t => t.Type.Equals("Expense", StringComparison.OrdinalIgnoreCase)).Sum(t => t.Amount);
            decimal balance = totalIncome - totalExpense;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"Total Income : £{totalIncome:F2}");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"Total Expense: £{totalExpense:F2}");
            Console.ResetColor();
            if (balance >= 0)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"Balance      : £{balance:F2}");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Balance      : £{balance:F2}");
            }
            Console.ResetColor();
            Console.WriteLine();
            GraphHelper.DisplayCategoryGraph(transactions);
            Console.WriteLine("\nPress any key to continue...");
            Console.ReadKey();
        }
        public void DeleteTransaction()
        {
            Console.Clear();
            if (transactions.Count == 0)
            {
                Console.WriteLine("No transactions to delete.");
                Console.ReadKey();
                return;
            }
            ListTransactions();
            Console.Write("\nEnter date of transaction to delete (yyyy-mm-dd): ");
            string dateStr = Console.ReadLine();
            var toRemove = transactions.FirstOrDefault(t => t.Date.ToString("yyyy-MM-dd") == dateStr);
            if (toRemove != null)
            {
                dbService.DeleteTransaction(toRemove.Id);
                transactions.Remove(toRemove);
                Console.WriteLine("\nTransaction deleted successfully.");
            }
            else
            {
                Console.WriteLine("No transaction found on that date.");
            }
            Console.ReadKey();
        }
        public void ShowMonthlyReport()
        {
            Console.Clear();
            Console.Write("Enter month (1–12): ");
            if (!int.TryParse(Console.ReadLine(), out int m) || m < 1 || m > 12)
            {
                Console.WriteLine("Invalid month."); Console.ReadKey(); return;
            }
            Console.Write("Enter year: ");
            if (!int.TryParse(Console.ReadLine(), out int y) || y < 1900 || y > 3000)
            {
                Console.WriteLine("Invalid year."); Console.ReadKey(); return;
            }
            ReportGenerator.Monthly(dbService, y, m);
        }
        public void ShowYearlyReport()
        {
            Console.Clear();
            Console.Write("Enter year: ");
            if (!int.TryParse(Console.ReadLine(), out int y) || y < 1900 || y > 3000)
            {
                Console.WriteLine("Invalid year."); Console.ReadKey(); return;
            }
            ReportGenerator.Yearly(dbService, y);
        }
        public void ExportCsv()
        {
            Console.Clear();
            Console.WriteLine("1) Export ALL transactions");
            Console.WriteLine("2) Export a specific MONTH");
            Console.Write("Choose: ");
            var c = Console.ReadLine();

            if (c == "1")
            {
                string path = "Data/exports/all_transactions.csv";
                CsvExporter.ExportAll(transactions, path);
                Console.WriteLine($"\nExported → {Path.GetFullPath(path)}");
            }
            else if (c == "2")
            {
                Console.Write("Enter month (1–12): ");
                if (!int.TryParse(Console.ReadLine(), out int m) || m < 1 || m > 12)
                { Console.WriteLine("Invalid month."); Console.ReadKey(); return; }
                Console.Write("Enter year: ");
                if (!int.TryParse(Console.ReadLine(), out int y))
                { Console.WriteLine("Invalid year."); Console.ReadKey(); return; }

                string path = $"Data/exports/transactions_{y}-{m:00}.csv";
                CsvExporter.ExportMonth(dbService, y, m, path);
                Console.WriteLine($"\nExported → {Path.GetFullPath(path)}");
            }
            else
            {
                Console.WriteLine("Cancelled.");
            }

            Console.WriteLine("\nPress any key...");
            Console.ReadKey();
        }
        public void ManageBudgets()
        {
            Console.Clear();
            Console.WriteLine("=== Budget Planning (Planned per Category) ===");
            var budgets = dbService.GetBudgets();
            if (budgets.Count == 0) Console.WriteLine("(no budgets set yet)");
            else
            {
                Console.WriteLine("Current planned amounts:");
                foreach (var b in budgets)
                    Console.WriteLine($" - {b.Category}: £{b.Planned:F2}");
            }

            Console.WriteLine("\nEnter planned amount for each expense category (blank to skip):");
            foreach (var cat in expenseCategories)
            {
                Console.Write($"{cat}: £");
                var input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input)) continue;
                if (decimal.TryParse(input, out var planned) && planned >= 0)
                {
                    dbService.UpsertBudget(new Budget(cat, planned));
                }
                else
                {
                    Console.WriteLine("  (invalid, skipped)");
                }
            }

            Console.WriteLine("\nSaved. Press any key...");
            Console.ReadKey();
        }
        public void ShowOverspendWarnings()
        {
            Console.Clear();
            Console.Write("Check overspending for which month (1–12): ");
            if (!int.TryParse(Console.ReadLine(), out int m) || m < 1 || m > 12)
            { Console.WriteLine("Invalid month."); Console.ReadKey(); return; }
            Console.Write("Year: ");
            if (!int.TryParse(Console.ReadLine(), out int y))
            { Console.WriteLine("Invalid year."); Console.ReadKey(); return; }
            var planned = dbService.GetBudgets();
            var actualByCat = dbService.GetCategorySpendForMonth(y, m); 

            Console.WriteLine($"\n=== Overspending Check — {y}-{m:00} ===");
            bool any = false;
            foreach (var p in planned)
            {
                actualByCat.TryGetValue(p.Category, out var actual);
                decimal remaining = p.Planned - actual;

                if (remaining < 0)
                {
                    any = true;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"{p.Category,-14} Planned £{p.Planned:F2} | Actual £{actual:F2} | OVER by £{-remaining:F2}");
                    Console.ResetColor();
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"{p.Category,-14} Planned £{p.Planned:F2} | Actual £{actual:F2} | Remaining £{remaining:F2}");
                    Console.ResetColor();
                }
            }

            if (!any)
                Console.WriteLine("\nNo overspending detected.");

            Console.WriteLine("\nPress any key...");
            Console.ReadKey();
        }
        private string SelectCategory(string type)
        {
            var list = type.Equals("Income", StringComparison.OrdinalIgnoreCase) ? incomeCategories : expenseCategories;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"\nSelect a category for {type}:");
            Console.ResetColor();
            for (int i = 0; i < list.Count; i++)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"{i + 1}. {list[i]}");
                Console.ResetColor();
            }

            Console.Write("Enter number: ");
            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > list.Count)
            {
                Console.Write("Invalid choice, try again: ");
            }

            return list[choice - 1];
        }
    }
}