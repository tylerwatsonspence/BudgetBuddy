﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Data.Sqlite;
using BudgetBuddy.Models;

namespace BudgetBuddy.Services
{
    public class DatabaseService
    {
        private readonly string connectionString = "Data Source=Data/transactions.db";
        public DatabaseService()
        {
            Directory.CreateDirectory("Data");

            using var connection = new SqliteConnection(connectionString);
            connection.Open();
            string txSql = @"CREATE TABLE IF NOT EXISTS Transactions (
                                Id TEXT PRIMARY KEY,
                                Date TEXT,
                                Type TEXT,
                                Category TEXT,
                                Amount REAL,
                                Description TEXT
                             );";
            new SqliteCommand(txSql, connection).ExecuteNonQuery();
            string budgetSql = @"CREATE TABLE IF NOT EXISTS Budgets (
                                    Category TEXT PRIMARY KEY,
                                    Planned REAL NOT NULL
                                 );";
            new SqliteCommand(budgetSql, connection).ExecuteNonQuery();
            string recurSql = @"CREATE TABLE IF NOT EXISTS Recurrences (
                                   Id TEXT PRIMARY KEY,
                                   Name TEXT,
                                   Type TEXT,
                                   Category TEXT,
                                   Amount REAL,
                                   DayOfMonth INTEGER,
                                   Description TEXT
                                );";
            new SqliteCommand(recurSql, connection).ExecuteNonQuery();
            string appliedSql = @"CREATE TABLE IF NOT EXISTS RecurrenceApplied (
                                     RecurrenceId TEXT,
                                     Year INTEGER,
                                     Month INTEGER,
                                     UNIQUE(RecurrenceId, Year, Month)
                                  );";
            new SqliteCommand(appliedSql, connection).ExecuteNonQuery();
            string settingsSql = @"CREATE TABLE IF NOT EXISTS Settings (
                                     Key TEXT PRIMARY KEY,
                                     Value TEXT
                                   );";
            new SqliteCommand(settingsSql, connection).ExecuteNonQuery();
        }
        public void AddTransaction(Transaction t)
        {
            using var con = new SqliteConnection(connectionString);
            con.Open();
            string sql = @"INSERT INTO Transactions
                           (Id, Date, Type, Category, Amount, Description)
                           VALUES (@Id,@Date,@Type,@Cat,@Amt,@Desc);";

            using var cmd = new SqliteCommand(sql, con);
            cmd.Parameters.AddWithValue("@Id", t.Id.ToString());
            cmd.Parameters.AddWithValue("@Date", t.Date.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@Type", t.Type);
            cmd.Parameters.AddWithValue("@Cat", t.Category);
            cmd.Parameters.AddWithValue("@Amt", t.Amount);
            cmd.Parameters.AddWithValue("@Desc", t.Description ?? "");
            cmd.ExecuteNonQuery();
        }
        public List<Transaction> GetAllTransactions()
        {
            List<Transaction> list = new();
            using var con = new SqliteConnection(connectionString);
            con.Open();

            using var cmd = new SqliteCommand("SELECT * FROM Transactions ORDER BY Date;", con);
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                list.Add(new Transaction(
                    DateTime.Parse(r["Date"].ToString()!),
                    r["Type"].ToString()!,
                    r["Category"].ToString()!,
                    Convert.ToDecimal(r["Amount"]),
                    r["Description"].ToString()!)
                { Id = Guid.Parse(r["Id"].ToString()!) });
            }
            return list;
        }
        public List<Transaction> GetTransactionsForMonth(int year, int month)
        {
            List<Transaction> list = new();
            using var con = new SqliteConnection(connectionString);
            con.Open();
            string sql = @"SELECT * FROM Transactions
                           WHERE strftime('%Y', Date) = @Y
                             AND strftime('%m', Date) = @M
                           ORDER BY Date;";
            using var cmd = new SqliteCommand(sql, con);
            cmd.Parameters.AddWithValue("@Y", year.ToString("0000"));
            cmd.Parameters.AddWithValue("@M", month.ToString("00"));
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                list.Add(new Transaction(
                    DateTime.Parse(r["Date"].ToString()!),
                    r["Type"].ToString()!,
                    r["Category"].ToString()!,
                    Convert.ToDecimal(r["Amount"]),
                    r["Description"].ToString()!)
                { Id = Guid.Parse(r["Id"].ToString()!) });
            }
            return list;
        }
        public (decimal income, decimal expense) GetTotalsForMonth(int year, int month)
        {
            using var con = new SqliteConnection(connectionString);
            con.Open();
            static decimal Sum(SqliteConnection c, string type, int y, int m)
            {
                string sql = @"SELECT IFNULL(SUM(Amount),0)
                               FROM Transactions
                               WHERE Type=@T
                                 AND strftime('%Y',Date)=@Y
                                 AND strftime('%m',Date)=@M;";
                using var cmd = new SqliteCommand(sql, c);
                cmd.Parameters.AddWithValue("@T", type);
                cmd.Parameters.AddWithValue("@Y", y.ToString("0000"));
                cmd.Parameters.AddWithValue("@M", m.ToString("00"));
                return Convert.ToDecimal(cmd.ExecuteScalar());
            }
            var inc = Sum(con, "Income", year, month);
            var exp = Sum(con, "Expense", year, month);
            return (inc, exp);
        }
        public Dictionary<string, decimal> GetCategorySpendForMonth(int year, int month)
        {
            Dictionary<string, decimal> dict = new();
            using var con = new SqliteConnection(connectionString);
            con.Open();
            string sql = @"SELECT Category, IFNULL(SUM(Amount),0) AS Total
                           FROM Transactions
                           WHERE Type='Expense'
                             AND strftime('%Y',Date)=@Y
                             AND strftime('%m',Date)=@M
                           GROUP BY Category
                           ORDER BY Total DESC;";
            using var cmd = new SqliteCommand(sql, con);
            cmd.Parameters.AddWithValue("@Y", year.ToString("0000"));
            cmd.Parameters.AddWithValue("@M", month.ToString("00"));
            using var r = cmd.ExecuteReader();
            while (r.Read())
                dict[r["Category"].ToString()!] = Convert.ToDecimal(r["Total"]);
            return dict;
        }
        public (decimal income, decimal expense) GetTotalsForYear(int year)
        {
            using var con = new SqliteConnection(connectionString);
            con.Open();
            static decimal Sum(SqliteConnection c, string type, int y)
            {
                string sql = @"SELECT IFNULL(SUM(Amount),0)
                               FROM Transactions
                               WHERE Type=@T
                                 AND strftime('%Y',Date)=@Y;";
                using var cmd = new SqliteCommand(sql, c);
                cmd.Parameters.AddWithValue("@T", type);
                cmd.Parameters.AddWithValue("@Y", y.ToString("0000"));
                return Convert.ToDecimal(cmd.ExecuteScalar());
            }
            var inc = Sum(con, "Income", year);
            var exp = Sum(con, "Expense", year);
            return (inc, exp);
        }
        public Dictionary<string, decimal> GetCategorySpendForYear(int year)
        {
            Dictionary<string, decimal> dict = new();
            using var con = new SqliteConnection(connectionString);
            con.Open();
            string sql = @"SELECT Category, IFNULL(SUM(Amount),0) AS Total
                           FROM Transactions
                           WHERE Type='Expense'
                             AND strftime('%Y',Date)=@Y
                           GROUP BY Category
                           ORDER BY Total DESC;";
            using var cmd = new SqliteCommand(sql, con);
            cmd.Parameters.AddWithValue("@Y", year.ToString("0000"));
            using var r = cmd.ExecuteReader();
            while (r.Read())
                dict[r["Category"].ToString()!] = Convert.ToDecimal(r["Total"]);
            return dict;
        }
        public void DeleteTransaction(Guid id)
        {
            using var con = new SqliteConnection(connectionString);
            con.Open();

            using var cmd = new SqliteCommand("DELETE FROM Transactions WHERE Id=@Id;", con);
            cmd.Parameters.AddWithValue("@Id", id.ToString());
            cmd.ExecuteNonQuery();
        }
        public List<Budget> GetBudgets()
        {
            List<Budget> list = new();
            using var con = new SqliteConnection(connectionString);
            con.Open();

            using var cmd = new SqliteCommand("SELECT Category, Planned FROM Budgets;", con);
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                list.Add(new Budget(
                    r["Category"].ToString()!,
                    Convert.ToDecimal(r["Planned"])
                ));
            }
            return list;
        }
        public void UpsertBudget(Budget b)
        {
            using var con = new SqliteConnection(connectionString);
            con.Open();

            string sql = @"INSERT INTO Budgets (Category, Planned)
                           VALUES (@Cat,@Planned)
                           ON CONFLICT(Category)
                           DO UPDATE SET Planned=@Planned;";
            using var cmd = new SqliteCommand(sql, con);
            cmd.Parameters.AddWithValue("@Cat", b.Category);
            cmd.Parameters.AddWithValue("@Planned", b.Planned);
            cmd.ExecuteNonQuery();
        }
        public List<Recurrence> GetRecurrences()
        {
            List<Recurrence> list = new();
            using var con = new SqliteConnection(connectionString);
            con.Open();
            using var cmd = new SqliteCommand("SELECT * FROM Recurrences ORDER BY Name;", con);
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                var rec = new Recurrence(
                    r["Name"].ToString()!,
                    r["Type"].ToString()!,
                    r["Category"].ToString()!,
                    Convert.ToDecimal(r["Amount"]),
                    Convert.ToInt32(r["DayOfMonth"]),
                    r["Description"].ToString()!
                )
                {
                    Id = Guid.Parse(r["Id"].ToString()!)
                };
                list.Add(rec);
            }
            return list;
        }
        public void UpsertRecurrence(Recurrence r)
        {
            using var con = new SqliteConnection(connectionString);
            con.Open();
            string sql = @"INSERT INTO Recurrences (Id, Name, Type, Category, Amount, DayOfMonth, Description)
                           VALUES (@Id,@Name,@Type,@Cat,@Amt,@Dom,@Desc)
                           ON CONFLICT(Id) DO UPDATE SET
                               Name=@Name, Type=@Type, Category=@Cat, Amount=@Amt, DayOfMonth=@Dom, Description=@Desc;";
            using var cmd = new SqliteCommand(sql, con);
            cmd.Parameters.AddWithValue("@Id", r.Id.ToString());
            cmd.Parameters.AddWithValue("@Name", r.Name);
            cmd.Parameters.AddWithValue("@Type", r.Type);
            cmd.Parameters.AddWithValue("@Cat", r.Category);
            cmd.Parameters.AddWithValue("@Amt", r.Amount);
            cmd.Parameters.AddWithValue("@Dom", r.DayOfMonth);
            cmd.Parameters.AddWithValue("@Desc", r.Description ?? "");
            cmd.ExecuteNonQuery();
        }
        public void DeleteRecurrence(Guid id)
        {
            using var con = new SqliteConnection(connectionString);
            con.Open();
            using var cmd = new SqliteCommand("DELETE FROM Recurrences WHERE Id=@Id;", con);
            cmd.Parameters.AddWithValue("@Id", id.ToString());
            cmd.ExecuteNonQuery();
            using var cmd2 = new SqliteCommand("DELETE FROM RecurrenceApplied WHERE RecurrenceId=@Id;", con);
            cmd2.Parameters.AddWithValue("@Id", id.ToString());
            cmd2.ExecuteNonQuery();
        }
        public int ApplyRecurrencesForMonth(int year, int month)
        {
            int applied = 0;
            using var con = new SqliteConnection(connectionString);
            con.Open();
            List<(Guid Id, string Name, string Type, string Category, decimal Amount, int DOM, string Description)> recs = new();
            using (var cmd = new SqliteCommand("SELECT * FROM Recurrences;", con))
            using (var r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    recs.Add((
                        Guid.Parse(r["Id"].ToString()!),
                        r["Name"].ToString()!,
                        r["Type"].ToString()!,
                        r["Category"].ToString()!,
                        Convert.ToDecimal(r["Amount"]),
                        Convert.ToInt32(r["DayOfMonth"]),
                        r["Description"].ToString()!
                    ));
                }
            }

            foreach (var rec in recs)
            {
                string existsSql = @"SELECT 1 FROM RecurrenceApplied
                                     WHERE RecurrenceId=@Rid AND Year=@Y AND Month=@M LIMIT 1;";
                using var existsCmd = new SqliteCommand(existsSql, con);
                existsCmd.Parameters.AddWithValue("@Rid", rec.Id.ToString());
                existsCmd.Parameters.AddWithValue("@Y", year);
                existsCmd.Parameters.AddWithValue("@M", month);
                var already = existsCmd.ExecuteScalar();
                if (already != null) continue;

                int day = Math.Clamp(rec.DOM, 1, DateTime.DaysInMonth(year, month));
                var date = new DateTime(year, month, day);
                var t = new Transaction(date, rec.Type, rec.Category, rec.Amount, string.IsNullOrWhiteSpace(rec.Name) ? rec.Description : $"{rec.Name} - {rec.Description}");
                AddTransaction(t);
                string insMark = @"INSERT OR IGNORE INTO RecurrenceApplied (RecurrenceId, Year, Month)
                                   VALUES (@Rid,@Y,@M);";
                using var markCmd = new SqliteCommand(insMark, con);
                markCmd.Parameters.AddWithValue("@Rid", rec.Id.ToString());
                markCmd.Parameters.AddWithValue("@Y", year);
                markCmd.Parameters.AddWithValue("@M", month);
                markCmd.ExecuteNonQuery();

                applied++;
            }
            return applied;
        }
        public string? GetSetting(string key)
        {
            using var con = new SqliteConnection(connectionString);
            con.Open();
            using var cmd = new SqliteCommand("SELECT Value FROM Settings WHERE Key=@K;", con);
            cmd.Parameters.AddWithValue("@K", key);
            var result = cmd.ExecuteScalar();
            return result?.ToString();
        }

        public void SetSetting(string key, string value)
        {
            using var con = new SqliteConnection(connectionString);
            con.Open();
            string sql = @"INSERT INTO Settings (Key, Value) VALUES (@K,@V)
                           ON CONFLICT(Key) DO UPDATE SET Value=@V;";
            using var cmd = new SqliteCommand(sql, con);
            cmd.Parameters.AddWithValue("@K", key);
            cmd.Parameters.AddWithValue("@V", value);
            cmd.ExecuteNonQuery();
        }
    }
}