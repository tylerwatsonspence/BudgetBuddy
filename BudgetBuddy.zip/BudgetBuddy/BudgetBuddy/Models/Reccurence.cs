﻿using System;

namespace BudgetBuddy.Models
{
    public class Recurrence
    {
        public Guid Id { get; set; }
        public string Name { get; set; }         // e.g., "Rent", "Salary"
        public string Type { get; set; }         // "Income" or "Expense"
        public string Category { get; set; }
        public decimal Amount { get; set; }
        public int DayOfMonth { get; set; }      // 1..31 (clamped to last day)
        public string Description { get; set; }

        public Recurrence(string name, string type, string category, decimal amount, int dayOfMonth, string description)
        {
            Id = Guid.NewGuid();
            Name = name;
            Type = type;
            Category = category;
            Amount = amount;
            DayOfMonth = dayOfMonth;
            Description = description;
        }

        public override string ToString()
        {
            return $"{Name} | {Type} | {Category} | £{Amount:F2} | Day {DayOfMonth} | {Description}";
        }
    }
}