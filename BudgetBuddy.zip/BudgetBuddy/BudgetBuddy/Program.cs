﻿using System;
using BudgetBuddy.Services;
using BudgetBuddy.Reports;

namespace BudgetBuddy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "BudgetBuddy - Personal Finance Tracker";
            var manager = new BudgetManager();

            while (true)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("=== BudgetBuddy ===");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("1. Add Transaction");
                Console.WriteLine("2. View Transactions");
                Console.WriteLine("3. View Summary (with Graph)");
                Console.WriteLine("4. Delete Transaction");
                Console.WriteLine("5. Monthly Report");
                Console.WriteLine("6. Yearly Report");
                Console.WriteLine("7. Export CSV");
                Console.WriteLine("8. Manage Budgets");
                Console.WriteLine("9. Overspending Warnings");
                Console.WriteLine("A. Manage Recurring");
                Console.WriteLine("B. Apply Recurring (Month)");
                Console.WriteLine("C. View Balance Graph (X–Y)");
                Console.WriteLine("S. Settings");
                Console.WriteLine("0. Exit");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("\nSelect an option: ");
                Console.ResetColor();
                string? choice = Console.ReadLine();

                switch (choice)
                {
                    case "1": manager.AddTransaction(); break;
                    case "2": manager.ListTransactions(); break;
                    case "3": manager.ShowSummaryWithGraph(); break;
                    case "4": manager.DeleteTransaction(); break;
                    case "5": manager.ShowMonthlyReport(); break;
                    case "6": manager.ShowYearlyReport(); break;
                    case "7": manager.ExportCsv(); break;
                    case "8": manager.ManageBudgets(); break;
                    case "9": manager.ShowOverspendWarnings(); break;
                    case "0": return;
                    case "A": case "a": manager.ManageRecurrences(); break;
                    case "B": case "b": manager.ApplyRecurrences(); break;
                    case "C": case "c": manager.ShowBalanceGraph(); break;
                    case "S": case "s": manager.SettingsMenu(); break;
                    default:
                        Console.WriteLine("Invalid option. Press any key...");
                        Console.ReadKey();
                        break;
                }
            }
        }
    }
}